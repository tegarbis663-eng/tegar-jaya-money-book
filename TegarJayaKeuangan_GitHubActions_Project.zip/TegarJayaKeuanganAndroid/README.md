# Tegar Jaya Keuangan — Android Studio Project

Project Android sederhana untuk menjalankan aplikasi Tegar Jaya Keuangan V2 secara offline menggunakan WebView.

## Cara membuka
1. Ekstrak ZIP.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `TegarJayaKeuanganAndroid`.
4. Tunggu Gradle Sync selesai.
5. Hubungkan HP Android dengan USB debugging atau gunakan emulator.
6. Klik **Run ▶** untuk menjalankan.
7. Untuk APK: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

## Data
Data transaksi/katalog disimpan di `localStorage` WebView pada perangkat. Tidak membutuhkan internet untuk menjalankan aplikasi.

## Package
`com.tegarjaya.keuangan`

## Versi
1.0
