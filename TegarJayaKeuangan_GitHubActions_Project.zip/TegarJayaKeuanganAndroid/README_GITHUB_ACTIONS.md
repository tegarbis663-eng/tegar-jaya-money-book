# Tegar Jaya Keuangan — Build APK lewat GitHub Actions

Project ini sudah dilengkapi workflow untuk membuat APK otomatis di GitHub, jadi tidak perlu Android Studio atau laptop untuk proses build.

## Cara dari HP

1. Buat repository baru di GitHub, misalnya `TegarJayaKeuangan`.
2. Upload **semua isi folder project ini** ke repository. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
3. Setelah upload selesai, buka tab **Actions** di repository.
4. Pilih workflow **Build APK**.
5. Tekan **Run workflow** jika belum otomatis berjalan. Pilih branch `main` lalu jalankan.
6. Tunggu sampai status menjadi hijau **Success**.
7. Buka hasil workflow tersebut, lalu bagian **Artifacts** → `TegarJayaKeuangan-debug-apk`.
8. Download ZIP artifact, ekstrak, lalu install file `.apk` di HP Android.

Workflow menggunakan JDK 17 dan Gradle 8.9 untuk project Android ini.
